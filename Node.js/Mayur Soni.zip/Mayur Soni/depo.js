var a =  require('./depAmt')
var dep=100
var nm = "Ram"
//call methods
a.check(dep,nm)

